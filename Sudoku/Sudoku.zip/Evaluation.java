//package sudoku;

public enum Evaluation {
	
	ACCEPT,ABANDON,CONTINUE;

}
